# ─────────────────────────────────────────────────────────────────────────────
# Maa Flavours — n8n Server on Oracle Cloud (AMD Micro — Always Free)
# Shape: VM.Standard.E2.1.Micro (1 OCPU, 1 GB RAM)
# Region: ap-hyderabad-1
# ─────────────────────────────────────────────────────────────────────────────

terraform {
  required_providers {
    oci = {
      source  = "oracle/oci"
      version = ">= 5.0.0"
    }
  }
}

provider "oci" {
  region = var.region
  auth   = "InstancePrincipal"
}

# ── Variables ─────────────────────────────────────────────────────────────────
variable "compartment_ocid" {
  description = "Your OCI Compartment OCID"
  type        = string
}

variable "ssh_public_key" {
  description = "Your SSH public key (contents of id_rsa.pub or id_ed25519.pub)"
  type        = string
}

variable "region" {
  description = "OCI region"
  type        = string
  default     = "ap-hyderabad-1"
}

# ── Get Ubuntu 22.04 image for AMD ───────────────────────────────────────────
data "oci_core_images" "ubuntu_amd" {
  compartment_id           = var.compartment_ocid
  operating_system         = "Canonical Ubuntu"
  operating_system_version = "22.04"
  shape                    = "VM.Standard.E2.1.Micro"
  sort_by                  = "TIMECREATED"
  sort_order               = "DESC"
}

# ── VCN ──────────────────────────────────────────────────────────────────────
resource "oci_core_vcn" "n8n_vcn" {
  compartment_id = var.compartment_ocid
  cidr_block     = "10.0.0.0/16"
  display_name   = "maa-flavours-vcn"
  dns_label      = "maaflavoursvcn"
}

# ── Internet Gateway ──────────────────────────────────────────────────────────
resource "oci_core_internet_gateway" "n8n_igw" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.n8n_vcn.id
  display_name   = "maa-flavours-igw"
  enabled        = true
}

# ── Route Table ───────────────────────────────────────────────────────────────
resource "oci_core_route_table" "n8n_rt" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.n8n_vcn.id
  display_name   = "maa-flavours-rt"

  route_rules {
    network_entity_id = oci_core_internet_gateway.n8n_igw.id
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
  }
}

# ── Security List (firewall rules) ────────────────────────────────────────────
resource "oci_core_security_list" "n8n_sl" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.n8n_vcn.id
  display_name   = "maa-flavours-sl"

  # Allow all outbound
  egress_security_rules {
    destination = "0.0.0.0/0"
    protocol    = "all"
  }

  # SSH
  ingress_security_rules {
    protocol = "6"
    source   = "0.0.0.0/0"
    tcp_options {
      min = 22
      max = 22
    }
  }

  # HTTP (for Let's Encrypt)
  ingress_security_rules {
    protocol = "6"
    source   = "0.0.0.0/0"
    tcp_options {
      min = 80
      max = 80
    }
  }

  # HTTPS (n8n)
  ingress_security_rules {
    protocol = "6"
    source   = "0.0.0.0/0"
    tcp_options {
      min = 443
      max = 443
    }
  }
}

# ── Subnet ────────────────────────────────────────────────────────────────────
resource "oci_core_subnet" "n8n_subnet" {
  compartment_id    = var.compartment_ocid
  vcn_id            = oci_core_vcn.n8n_vcn.id
  cidr_block        = "10.0.1.0/24"
  display_name      = "maa-flavours-subnet"
  dns_label         = "maaflavoursnet"
  route_table_id    = oci_core_route_table.n8n_rt.id
  security_list_ids = [oci_core_security_list.n8n_sl.id]
}

# ── VM Instance (AMD Micro) ───────────────────────────────────────────────────
resource "oci_core_instance" "n8n_vm" {
  compartment_id      = var.compartment_ocid
  availability_domain = data.oci_identity_availability_domains.ads.availability_domains[0].name
  display_name        = "maa-flavours-n8n"
  shape               = "VM.Standard.E2.1.Micro"

  source_details {
    source_type             = "image"
    source_id               = data.oci_core_images.ubuntu_amd.images[0].id
    boot_volume_size_in_gbs = 50  # Free tier minimum
  }

  create_vnic_details {
    subnet_id        = oci_core_subnet.n8n_subnet.id
    assign_public_ip = true
    display_name     = "maa-flavours-vnic"
  }

  metadata = {
    ssh_authorized_keys = var.ssh_public_key
  }

  preserve_boot_volume = false
}

# ── Get Availability Domains ──────────────────────────────────────────────────
data "oci_identity_availability_domains" "ads" {
  compartment_id = var.compartment_ocid
}

# ── Outputs ───────────────────────────────────────────────────────────────────
output "instance_public_ip" {
  description = "Public IP of n8n server — update DNS record in Vercel to this IP"
  value       = oci_core_instance.n8n_vm.public_ip
}

output "ssh_command" {
  description = "SSH command to connect to the server"
  value       = "ssh ubuntu@${oci_core_instance.n8n_vm.public_ip}"
}
